using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using TMPro;

public class GameManager : MonoBehaviour
{
    [Header("Elements")]
    public GameObject tilePrefab;
    public Transform gridContainer;
    public CanvasGroup gridCanvasGroup; 
    
    [Header("UI References")]
    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI trialText;
    public TextMeshProUGUI mistakesText;
    public TextMeshProUGUI finalMessageText; 

    [Header("Game Settings")]
    public int totalTiles = 36;       
    public int totalTrials = 6;       
    public float showDuration = 3.0f; // وقت عرض الباترن للحفظ
    public float playDuration = 60.0f; // وقت اللعب (دقيقتين) <-- الجديد هنا
    public int maxMistakes = 4;       
    public int scoreToWin = 3600;

    private List<TileController> allTiles = new List<TileController>();
    private List<TileController> currentPattern = new List<TileController>();
    
    private int currentTrial = 0;
    private int currentScore = 0;
    private int currentMistakes = 0;
    private int patternSize = 5; 
    
    private Coroutine turnTimer; // متغير عشان نتحكم في العداد

    void Start()
    {
        if (gridCanvasGroup == null && gridContainer != null)
             gridCanvasGroup = gridContainer.GetComponent<CanvasGroup>();

        if(finalMessageText != null) finalMessageText.gameObject.SetActive(false);
        
        GenerateMatrix();
        StartCoroutine(StartNewTrial());
    }

    void GenerateMatrix()
    {
        foreach (Transform child in gridContainer) Destroy(child.gameObject);
        allTiles.Clear();

        for (int i = 0; i < totalTiles; i++)
        {
            GameObject newTileObj = Instantiate(tilePrefab, gridContainer);
            TileController tile = newTileObj.GetComponent<TileController>();
            tile.gameManager = this;
            allTiles.Add(tile);
        }
    }

    IEnumerator StartNewTrial()
    {
        if (gridCanvasGroup != null) gridCanvasGroup.alpha = 1f;

        currentTrial++;
        UpdateUI();

        if (currentTrial > totalTrials)
        {
            ShowFinalResult();
            yield break;
        }

        currentMistakes = 0;
        foreach (var tile in allTiles) tile.ResetTile();
        UpdateUI(); 

        yield return new WaitForSeconds(1.0f); 

        GenerateRandomPattern();

        // مرحلة الحفظ
        foreach (var tile in currentPattern) tile.HighlightTile();
        yield return new WaitForSeconds(showDuration);
        foreach (var tile in currentPattern) tile.HideTile();

        // مرحلة اللعب
        foreach (var tile in allTiles) tile.EnableInteraction(true);
        
        // تشغيل العداد (دقيقتين) أول ما يبدأ اللعب
        if (turnTimer != null) StopCoroutine(turnTimer);
        turnTimer = StartCoroutine(PlayTimer());
    }

    // العداد الجديد
    IEnumerator PlayTimer()
    {
        yield return new WaitForSeconds(playDuration);
        // لو الوقت خلص واللاعب لسه مخلصش، اعتبرها خسارة وانقل للي بعده
        EndTrial(false);
    }

    void GenerateRandomPattern()
    {
        currentPattern.Clear();
        List<TileController> shuffledTiles = new List<TileController>(allTiles);
        for (int i = 0; i < shuffledTiles.Count; i++) {
            TileController temp = shuffledTiles[i];
            int randomIndex = Random.Range(i, shuffledTiles.Count);
            shuffledTiles[i] = shuffledTiles[randomIndex];
            shuffledTiles[randomIndex] = temp;
        }

        for (int i = 0; i < patternSize; i++)
        {
            shuffledTiles[i].isTarget = true;
            currentPattern.Add(shuffledTiles[i]);
        }
    }

    public void CheckTile(TileController clickedTile)
    {
        if (clickedTile.wasClicked && clickedTile.isTarget)
        {
            EndTrial(false); 
            return;
        }

        clickedTile.wasClicked = true;

        if (clickedTile.isTarget)
        {
            currentScore += 100;
            clickedTile.SetColor(true); 

            if (CheckIfPatternComplete())
            {
                EndTrial(true);
            }
        }
        else
        {
            clickedTile.SetColor(false); 
            currentMistakes++;
            
            if (currentMistakes >= maxMistakes)
            {
                EndTrial(false);
            }
        }
        UpdateUI();
    }

    bool CheckIfPatternComplete()
    {
        int foundCount = 0;
        foreach (var tile in currentPattern)
        {
            if (tile.wasClicked) foundCount++;
        }
        return foundCount == currentPattern.Count;
    }

    void EndTrial(bool success)
    {
        // نوقف العداد عشان مينقلش مرتين بالغلط
        if (turnTimer != null) StopCoroutine(turnTimer);

        foreach (var tile in allTiles) tile.EnableInteraction(false);
        if (success) patternSize++; 
        StartCoroutine(StartNewTrial());
    }

    void UpdateUI()
    {
        if (scoreText) scoreText.text = "SCORE: " + currentScore;
        if (trialText && currentTrial <= totalTrials) trialText.text = "TRIAL: " + currentTrial + " / " + totalTrials;
        if (mistakesText) mistakesText.text = "MISTAKES: " + currentMistakes + " / " + maxMistakes;
    }

    void ShowFinalResult()
    {
        if (gridCanvasGroup != null) 
            gridCanvasGroup.alpha = 0.3f; 

        if(finalMessageText != null)
        {
            finalMessageText.gameObject.SetActive(true);
            if (currentScore >= scoreToWin)
            {
                finalMessageText.text = "You Are Ready To Fight";
                finalMessageText.color = Color.green;
            }
            else
            {
                finalMessageText.text = "Try Again!";
                finalMessageText.color = Color.red;
            }
        }
    }
}